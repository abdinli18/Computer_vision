#from mat4py import loadmat
import cv2
import numpy as np
from numpy.lib.function_base import average
import scipy.io
import os


mat_docs = os.listdir('D:/D_M/Downloads/Computer_vision/Homeworks/HW3/BSR/BSDS500/data/groundTruth/test')

image_docs = os.listdir("D:/D_M/Downloads/Computer_vision/Homeworks/HW3/BSR/BSDS500/data/images/test")
#print(image_docs[0])


counter = 0
average_precision = float(0)

for matdoc in mat_docs:
    img = cv2.imread("D:/D_M/Downloads/Computer_vision/Homeworks/HW3/BSR/BSDS500/data/images/test/"+ image_docs[counter])
    #print(image_docs[counter])
    #print(matdoc)
    defaultimg = np.zeros((img.shape[0], img.shape[1]))
    mat = scipy.io.loadmat('D:/D_M/Downloads/Computer_vision/Homeworks/HW3/BSR/BSDS500/data/groundTruth/test/'+matdoc)
    for arr in mat["groundTruth"][0]:
        
        bound = arr["Boundaries"]
        bound = bound[0][0]

        defaultimg[bound>0] = 255
        #cv2.imshow("a", defaultimg)
        #cv2.waitKey(0)

    
    #100, 200 -> average precision: 14.993883869020094
    #150, 450 -> average precision: 22.2194720075022
    #120, 360 -> average precision: 19.19415659769906
    #120, 450 -> average precision: 20.88141322324316
    #130, 450 
    #300 300 -> 23
    #300 400 -> 25
    #300 500 -> 27
    #300 550 ->28.29
    #290 550 -> 28.13
    #310 550 -> 28.46
    #350 550 -> 29.0767
    #360 550 -> 29.2314
    #400 550 -> 29.7517
    #450 550 -> 30.387396
    #500 550 -> 30.903255
    #550 550 -> 31.329561951945077
    myCannyResult = cv2.Canny(img,150, 450)
    cv2.imwrite("D:/D_M/Downloads/Computer_vision/Homeworks/HW3/part1_finding/" + image_docs[counter], myCannyResult)

    #cv2.imshow("b",defaultimg)
    #cv2.imshow("a", myCannyResult)
    #cv2.waitKey()
    counter = counter+1
    print(counter)

    getTrue = 0
    getFalse = 0

    for i in range(len(myCannyResult)):
        for j in range(len(myCannyResult[0])):
            if(myCannyResult[i][j]==defaultimg[i][j] and myCannyResult[i][j]!=0):
                getTrue=getTrue+1
            elif(myCannyResult[i][j]!=0):
                getFalse = getFalse+1


    average_precision = average_precision + (getTrue/(getTrue+getFalse)*100)/200

print("average precision: ", average_precision)


