import cv2
import numpy as np
from numpy.lib.function_base import average
import scipy.io
import os
from sklearn.metrics import precision_score



mat_docs = os.listdir('D:/D_M/Downloads/Computer_vision/Homeworks/HW3/BSR/BSDS500/data/groundTruth/test')

network_results = os.listdir("D:/D_M/Downloads/Computer_vision/Homeworks/HW3/CATS-master/output/bsds/test/sing_scale_test")
#print(network_results[0])


counter = 0
average_precision = float(0)



for matdoc in mat_docs:
    img = cv2.imread("D:/D_M/Downloads/Computer_vision/Homeworks/HW3/CATS-master/output/bsds/test/sing_scale_test/"+ network_results[counter])

    defaultimg = np.zeros((img.shape[0], img.shape[1]))
    mat = scipy.io.loadmat('D:/D_M/Downloads/Computer_vision/Homeworks/HW3/BSR/BSDS500/data/groundTruth/test/'+matdoc)
    for arr in mat["groundTruth"][0]:
        
        bound = arr["Boundaries"]
        bound = bound[0][0]

        defaultimg[bound>0] = 255

    

    myNetworkResult = img
    	
    myNetworkResult = cv2.cvtColor(myNetworkResult, cv2.COLOR_BGR2GRAY)
    #cv2.imshow("a",myNetworkResult)
    #128 -> 42
    #140 -> 43.6887
    #150 -> 44.5114
    #165 -> 45.8263
    #175 -> 46.7212
    #180 -> 47.1997
    #185 -> 47.6896
    #200 -> 49.2666
    #210 -> 50.4336
    #230 -> 53.3003
    #245 -> 56.6649
    #250 -> 58.3210
    #254 -> 60.42731594680044
    myNetworkResult[myNetworkResult<128] = 0
    myNetworkResult[myNetworkResult>=128] = 255

    cv2.imwrite("D:/D_M/Downloads/Computer_vision/Homeworks/HW3/part2_finding/" + network_results[counter], myNetworkResult)
    #cv2.imshow("b",myNetworkResult)
    #cv2.waitKey()

    #cv2.imshow("b",defaultimg)
    #cv2.waitKey()
    counter = counter+1
    print(counter)

    getTrue = 0
    getFalse = 0

    for i in range(len(myNetworkResult)):
        for j in range(len(myNetworkResult[0])):
            if(myNetworkResult[i][j]==defaultimg[i][j] and myNetworkResult[i][j]!=0):
                getTrue=getTrue+1
            elif(myNetworkResult[i][j]!=0):
                getFalse = getFalse+1


    average_precision = average_precision + (getTrue/(getTrue+getFalse)*100)/200


print("average precision: ", average_precision)


