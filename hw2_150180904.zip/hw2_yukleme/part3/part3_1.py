import pyautogui
import time
import numpy as np
import cv2

# Elvin Abdinli
#ID: 150180904
#key presenting at the end of the dance.
# For Vabank: 227_182_6_101_215_112_153_82_105_206_94_57_159_66_88_46_115_28_249_124_28_44_194_154_57_235_24_166_207_230_113_5
# For Shame: 211_25_246_223_18_175_93_85_209_113_246_253_38_177_135_219_208_25_147_82_80_133_130_91_36_119_28_141_245_54_208_225

#My screen resolution: 1920 x 1080




time.sleep(5)

figures_detected = 0

keys_pressed = []

num_of_corners=0
num_of_corners_old = 0
while figures_detected < 18:

    myScreenshot = pyautogui.screenshot()
    image = np.array(myScreenshot)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    control_part = image[810:1081, 753:1050]
    control_part[control_part==206] = 255

    #print(image[880][880])
    corners = cv2.cornerMinEigenVal(control_part,2,1)

    #normalize
    corner_normalize = np.empty(corners.shape, dtype=np.float32)
    cv2.normalize(corners,corner_normalize,alpha=0,beta=255,norm_type=cv2.NORM_MINMAX)
    corner_normalize_scaled = cv2.convertScaleAbs(corner_normalize)

    num_corners = corner_normalize_scaled[corner_normalize_scaled>1].shape[0]

    corner_normalize_scaled = (255*(corner_normalize_scaled>45)).astype(np.uint8)

    #kernel = np.ones((3,3))
    #corner_normalize_scaled = cv2.erode(corner_normalize_scaled, kernel)


    
    img_count = 0
    if(np.any(control_part==0) and np.all(control_part[:,-1]==255)):
        #cv2.imshow('a',corner_normalize_scaled)
        #cv2.waitKey(0)
        kernel = np.ones((3,3))
        corner_normalize_scaled = cv2.dilate(corner_normalize_scaled, kernel)
        num_of_corners=cv2.connectedComponents(corner_normalize_scaled)[0] - 1
        figures_detected+=1
        print(num_of_corners)
        if(num_of_corners==6):
            pyautogui.keyDown('F')
            pyautogui.keyUp('F')
            keys_pressed.append('F')
            print('F')
        elif(num_of_corners==10):
            pyautogui.keyDown('D')
            pyautogui.keyUp('D')
            keys_pressed.append('D')
            print('D')
        elif(num_of_corners==3):
            pyautogui.keyDown('A')
            pyautogui.keyUp('A')
            keys_pressed.append('A')
            print('A')
        else:
            pyautogui.keyDown('S')
            pyautogui.keyUp('S')
            keys_pressed.append('S')
            print('S')
        print(keys_pressed)


    else:
        num_of_corners_old = num_of_corners
    

print(keys_pressed)