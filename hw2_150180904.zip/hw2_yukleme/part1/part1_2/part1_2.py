from PIL.Image import new
import numpy as np
import moviepy.video.io.VideoFileClip as mpy
import moviepy.editor as moviepy
import cv2
from numpy.core.fromnumeric import nonzero
from numpy.lib.function_base import median
from matplotlib import pyplot as plt
import scipy.ndimage.filters as filters 

def filter(img: np.ndarray, w_len = 3, sigma = 1):
    # https://stackoverflow.com/questions/25216382/gaussian-filter-in-scipy
    t = (((w_len - 1)/2)-0.5)/sigma
    return filters.gaussian_filter(img, sigma, truncate=t)


def findCornerCoordinates(frame,isproblematic):
    print(frame.shape)
    print(len(frame))
    print(len(frame[0]))
    corner_coor_row = []
    for i in range(len(frame)):
        if(np.any(frame[i]==255)):
            corner_coor_row.append(i)
            break
    
    for j in range(len(frame)-1,-1,-1):
        if(np.any(frame[j]==255)):
            corner_coor_row.append(j)
            break
    corner_coor_row.sort()
    corner_coor_col = []
    if(isproblematic):
        for t in range(len(frame[0])):
            if(np.any(frame[:,t]==255)):
                corner_coor_col.append(t)
                break
    else:
        begin = int(0.65*len(frame[0]))
        print(begin, "begin num")
        for t in range(begin,len(frame[0])):
            if(np.any(frame[:,t]==255)):
                corner_coor_col.append(t)
                break
    
    for k in range(len(frame[0])-1,-1,-1):
        if(np.any(frame[:,k]==255)):
            corner_coor_col.append(k)
            break
    corner_coor_col.sort()
    some_corner_coor = []
    some_corner_coor.append(corner_coor_row)
    some_corner_coor.append(corner_coor_col)

    return some_corner_coor









vid = mpy.VideoFileClip('part1_1_video.mp4')
#vid = mpy.VideoFileClip('shapes_video.mp4')

frame_count = vid.reader.nframes
video_fps = vid.fps
print(video_fps)
frames_list = []

print("Number of frames:",frame_count)

old_frame = vid.get_frame(0*1.0/video_fps)

old_frame = cv2.cvtColor(old_frame,cv2.COLOR_BGR2GRAY)
old_frame[old_frame<250]=0
old_frame = cv2.Canny(old_frame,10,300)

'''sinir = 100
old_frame = cv2.Canny(old_frame,100,300)
old_corners = cv2.cornerMinEigenVal(old_frame,2,1)
old_corner_normalize = np.empty(old_corners.shape, dtype=np.float32)
cv2.normalize(old_corners,old_corner_normalize,alpha=0,beta=255,norm_type=cv2.NORM_MINMAX)
Old_corner_normalize_scaled = cv2.convertScaleAbs(old_corner_normalize)
Old_corner_normalize_scaled = (255*(Old_corner_normalize_scaled>sinir)).astype(np.uint8)
cv2.imshow('old_frame', Old_corner_normalize_scaled)
cv2.waitKey(0)'''






'''for i in range(1,frame_count):

    new_frame = vid.get_frame(i*1.0/video_fps)
    new_frame_orginal = new_frame.copy()
    new_frame_orginal = cv2.cvtColor(new_frame_orginal,cv2.COLOR_BGR2GRAY)
    #new_frame = median_filter(new_frame)
    new_frame = cv2.cvtColor(new_frame,cv2.COLOR_BGR2GRAY)
    new_frame = cv2.Canny(new_frame,100,300)
    new_frame_orginal = cv2.Canny(new_frame_orginal,100,300)



    
    corners = cv2.cornerMinEigenVal(new_frame,2,1)
    corner_normalize = np.empty(corners.shape, dtype=np.float32)
    cv2.normalize(corners,corner_normalize,alpha=0,beta=255,norm_type=cv2.NORM_MINMAX)
    corner_normalize_scaled = cv2.convertScaleAbs(corner_normalize)
    corner_normalize_scaled = (255*(corner_normalize_scaled>sinir)).astype(np.uint8)







    new_frame = corner_normalize_scaled-Old_corner_normalize_scaled

    old_corners = cv2.cornerMinEigenVal(new_frame_orginal,2,1)
    old_corner_normalize = np.empty(old_corners.shape, dtype=np.float32)
    cv2.normalize(old_corners,old_corner_normalize,alpha=0,beta=255,norm_type=cv2.NORM_MINMAX)
    Old_corner_normalize_scaled = cv2.convertScaleAbs(corner_normalize)
    Old_corner_normalize_scaled = (255*(Old_corner_normalize_scaled>sinir)).astype(np.uint8)


    old_frame = Old_corner_normalize_scaled

    cv2.imshow('A', new_frame)
    cv2.waitKey(0)'''
yildiz = 0
kare = 0
besgen=0
unknown=0

for i in range(1,frame_count):

    new_frame = vid.get_frame(i*1.0/video_fps)
    new_frame_orginal = new_frame.copy()
    new_frame_orginal = cv2.cvtColor(new_frame_orginal,cv2.COLOR_BGR2GRAY)
    #new_frame_orginal[new_frame_orginal<250]=0
    #new_frame = median_filter(new_frame)
    new_frame = cv2.cvtColor(new_frame,cv2.COLOR_BGR2GRAY)

    new_frame = cv2.Canny(new_frame,50,300)
    new_frame[new_frame<250] = 0
    #foreground2 = np.logical_and(old_frame[:,:]<10, new_frame_orginal[:,:]>10)
    #nonzero_x_white, nonzero_y_white = np.nonzero(foreground2)
    #new_frame = new_frame-old_frame
    '''cv2.imshow('old',old_frame)
    cv2.waitKey()
    cv2.imshow('new',new_frame)
    cv2.waitKey()'''

    kernel = np.ones((3,3),np.float32)/9
    new_frame = cv2.filter2D(new_frame,-1,kernel)
    #old_frame = cv2.filter2D(old_frame,-1,kernel)

    new_frame = new_frame.astype(np.int16)

    #old_frame[old_frame<250] = 0
    new_frame = new_frame-old_frame
    new_frame[new_frame<0] = 0
    new_frame[new_frame>0] = 255
    new_frame = cv2.erode(new_frame,kernel)
    new_frame[new_frame<200] = 0
    new_frame = new_frame.astype(np.uint8)
    new_frame = cv2.dilate(new_frame, kernel)
    #new_frame = cv2.dilate(new_frame, kernel)
    #new_frame = cv2.dilate(new_frame, kernel)

#    _, comp = cv2.connectedComponents(new_frame)  # connected components analizi

#    cv2.imshow('a',comp) 
#    cv2.waitKey()

    #a = cv2.connectedComponentsWithStats(new_frame)
    #print(a[2])

    '''corners = cv2.cornerMinEigenVal(new_frame,2,1)
    corner_normalize = np.empty(corners.shape, dtype=np.float32)
    cv2.normalize(corners,corner_normalize,alpha=0,beta=255,norm_type=cv2.NORM_MINMAX)
    corner_normalize_scaled = cv2.convertScaleAbs(corner_normalize)

    corner = (255*(corner_normalize_scaled>50)).astype(np.uint8)'''
    contours, hierarchy = cv2.findContours(new_frame,cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

    print(len(contours))
    #img = cv2.cvtColor(new_frame, cv2.COLOR_GRAY2BGR)  #add this line

    #cv2.drawContours(img, contours, -1, (0,128,0), 2)
    cv2.drawContours(new_frame, contours, -1, (255, 255, 255), 3)
    cv2.imshow('b',new_frame)
    if( i==38 or i== 64):
        NotProb = False
        corner_coordinates = findCornerCoordinates(new_frame,NotProb)
    else:
        NotProb = True
        corner_coordinates = findCornerCoordinates(new_frame,NotProb)

    some_part_original_frame = new_frame_orginal.copy()

    if(len(corner_coordinates[0])>0):
        some_part_original_frame[0:corner_coordinates[0][0],:] = 255
        some_part_original_frame[corner_coordinates[0][1]:,:] = 255
        some_part_original_frame[:,0:corner_coordinates[1][0]]=255
        some_part_original_frame[:,corner_coordinates[1][1]:]=255

        some_part_original_frame[some_part_original_frame<100] = 0
        some_part_original_frame[some_part_original_frame>=100] = 255
        some_part_original_frame[some_part_original_frame==255] = 110
        some_part_original_frame[some_part_original_frame==0] = 255
        some_part_original_frame[some_part_original_frame==110]=0
        num_labels, labels = cv2.connectedComponents(some_part_original_frame)
        centerX = int((corner_coordinates[0][0]+corner_coordinates[0][1])/2)
        centerY = int((corner_coordinates[1][0]+corner_coordinates[1][1])/2)
        foreground = labels!=labels[centerX,centerY]
        nonzero_x, nonzero_y = np.nonzero(foreground)
        some_part_original_frame[nonzero_x, nonzero_y]=0
        #some_part_original_frame = filter(some_part_original_frame,7)
        kernel = np.ones((5,5),np.float32)/25
        some_part_original_frame = cv2.filter2D(some_part_original_frame,-1,kernel)
        some_part_original_frame = cv2.filter2D(some_part_original_frame,-1,kernel)

    
    if(i>=82 or i<7):
        some_part_original_frame[:,:] = 0

    corners = cv2.cornerMinEigenVal(some_part_original_frame,2,1)
    corners = corners/corners.max()

    ans_corner = (255*(corners>=0.05)).astype(np.uint8)
    ans_corner = cv2.medianBlur(ans_corner, 5)
    ans_corner = cv2.dilate(ans_corner,((5,5)))
    #ans_corner = cv2.medianBlur(ans_corner, 5)
    #ans_corner = cv2.erode(ans_corner,((5,5)))
    num_labels, labels = cv2.connectedComponents(ans_corner)
    num_labels = num_labels-1
    print(num_labels)
    if(num_labels==4):
        kare+=1
    elif(num_labels==10):
        yildiz+=1
    elif(num_labels==5):
        besgen+=1
    else:
        unknown+=1

    
    cv2.imshow('a',ans_corner)
    print(i, "frame num")
    cv2.waitKey(0)
    #cv2.imshow('Contours', new_frame)

    #cv2.imshow('A', new_frame)
    #cv2.waitKey(0)

    new_frame_orginal = cv2.Canny(new_frame_orginal,50,300)
    new_frame_orginal[new_frame_orginal<255] = 0
    new_frame_orginal = cv2.filter2D(new_frame_orginal,-1,kernel)
    old_frame = new_frame_orginal
    #old_frame = cv2.dilate(old_frame, np.ones((3,3)))
    old_frame[old_frame>0] = 255
    

    
    #old_frame = cv2.dilate(old_frame, np.ones((3,3)))
    #old_frame = cv2.Canny(new_frame_orginal,50,300)
    #kernel = np.ones((3,3),np.float32)/20
    #new_frame = cv2.filter2D(new_frame,-1,kernel)
    #new_frame[new_frame>10]= 255
    #new_kernel = np.ones((5,5))
    #new_frame = cv2.dilate(new_frame, new_kernel)
    #new_frame[new_frame>5] = 255

    '''corners = cv2.cornerMinEigenVal(new_frame,2,1)
    corner_normalize = np.empty(corners.shape, dtype=np.float32)
    cv2.normalize(corners,corner_normalize,alpha=0,beta=255,norm_type=cv2.NORM_MINMAX)
    corner_normalize_scaled = cv2.convertScaleAbs(corner_normalize)

    corner = (255*(corner_normalize_scaled>0)).astype(np.uint8)'''
    #corner = cv2.filter2D(corner,-1,new_kernel)



'''for i in range(1,frame_count):
    foreground = np.logical_or(0, old_frame[:,:]>10)
    #print(foreground)
    nonzero_x, nonzero_y = np.nonzero(foreground)
    new_frame = vid.get_frame(i*1.0/video_fps)
    new_frame_orginal = new_frame.copy()
    new_frame_orginal = cv2.cvtColor(new_frame_orginal,cv2.COLOR_BGR2GRAY)
    #new_frame = median_filter(new_frame)
    new_frame = cv2.cvtColor(new_frame,cv2.COLOR_BGR2GRAY)

    #foreground2 = np.logical_and(old_frame[:,:]<10, new_frame_orginal[:,:]>10)
    #nonzero_x_white, nonzero_y_white = np.nonzero(foreground2)
    #new_frame = new_frame-old_frame
    old_frame = new_frame_orginal
    new_frame[nonzero_x,nonzero_y]=0

    #new_frame[nonzero_x_white,nonzero_y_white] = 255
    cv2.imshow("qq",new_frame)
    cv2.waitKey(0)'''

'''for i in range(frame_count):
    #foreground = np.logical_or(0, old_frame[:,:]>10)
    #print(foreground)
    #nonzero_x, nonzero_y = np.nonzero(foreground)
    new_frame = vid.get_frame(i*1.0/video_fps)
    #new_frame = median_filter(new_frame)
    new_frame = cv2.cvtColor(new_frame,cv2.COLOR_BGR2GRAY)
    #new_frame = new_frame-old_frame
    #new_frame[nonzero_x,nonzero_y]=0
    old_frame = new_frame
    cv2.imshow("qq",new_frame)
    cv2.waitKey(0) '''
    
    
    
'''gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)    
corners = cv2.goodFeaturesToTrack(gray,100,0.01,10)
corners = np.int0(corners)
for j in corners:
    x,y = j.ravel()
    cv2.circle(frame,(x,y),3,255,-1)

plt.imshow(frame),plt.show()'''


print(kare,"kare")
print(besgen,"besgen")
print(yildiz,"yildiz")
print(unknown,"There is not any figures")