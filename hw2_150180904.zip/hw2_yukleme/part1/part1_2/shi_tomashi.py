import numpy as np
import cv2
from PIL.Image import new
import moviepy.video.io.VideoFileClip as mpy
import moviepy.editor as moviepy
from numpy.core.fromnumeric import nonzero
from numpy.lib.function_base import median
from matplotlib import pyplot as plt


def findWindow(data,i,j):
    temp=[]
    for z in range(-1,2,1):
        if(i+z < 0 or i+z>len(data)-1):
            for k in range(3):
                temp.append(0)
        else:
            if(j+z<0 or j+1>len(data[0])-1):
                    temp.append(0)
            else:
                for k in range(-1,2,1):
                    temp.append(data[i+z][j+k])
    return np.array(temp)




def findCorners(img, thresh):
    dy, dx = np.gradient(img)
    Ixx = dx ** 2
    Iyy = dy ** 2
    Ixy = dy*dx
    height = img.shape[0]
    width = img.shape[1]

    cornerList = []
    # Search corners in image
    for y in range(0, height):
        for x in range(0, width):

            #windowIxx = Ixx[y :y  + 3, x :x  + 3]
            #windowIyy = Iyy[y :y  + 3, x :x  + 3]
            #windowIxy = Ixy[y:y+3, x:x+3]

            windowIxx = findWindow(Ixx,y,x)
            windowIyy = findWindow(Iyy,y,x)
            windowIxy = findWindow(Ixy,y,x)
            Sxx = windowIxx.sum()/9
            Syy = windowIyy.sum()/9
            Sxy = windowIxy.sum()/9
            #lambda1 = 0.5*((Sxx+Syy)+((Sxx-Syy)**2 + 4*(Sxy**2))**0.5)
            lambda2 = 0.5*((Sxx+Syy)-((Sxx-Syy)**2 + 4*(Sxy**2))**0.5)
            
            
            r = lambda2

            # Threshold for corner
            if r > thresh:
                cornerList.append([x, y, r])
    return cornerList


vid = mpy.VideoFileClip('part1_1_video.mp4')
#vid = mpy.VideoFileClip('shapes_video.mp4')

frame_count = vid.reader.nframes
video_fps = vid.fps
print(video_fps)
frames_list = []


for i in range(1,frame_count):
    new_frame = vid.get_frame(i*1.0/video_fps)
    new_frame_orginal = new_frame.copy()
    new_frame_orginal = cv2.cvtColor(new_frame_orginal,cv2.COLOR_BGR2GRAY)

    color_img = new_frame



    img = cv2.cvtColor(color_img, cv2.COLOR_RGB2GRAY)

    #print(img.shape)

    maxCorners = 5000
    thresh = 0
    #dist = 10

    corners = findCorners(img, thresh)

    corner_image = img.copy()

    #print(corner_image.shape)

    corner_image[:,:] = 0

    print(len(corners))

    for i in range(len(corners)):
        corner_image[corners[i][1],corners[i][0]]=255

    cv2.imshow('A', corner_image)
    cv2.waitKey()