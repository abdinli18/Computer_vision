import numpy as np
import moviepy.video.io.VideoFileClip as mpy
import moviepy.editor as moviepy
import cv2
from numpy.lib.function_base import median

def median_filter(data):
    #print(data.shape)
    final_image = np.zeros((len(data), len(data[0]),3))
    #print(final_image.shape)
    for i in range(len(data)):
        for j in range(len(data[0])):
            temp=[]
            for z in range(-1,2,1):
                if(i+z < 0 or i+z>len(data)-1):
                    for k in range(3):
                        temp.append(0)
                else:
                    if(j+z<0 or j+1>len(data[0])-1):
                        temp.append(0)
                    else:
                        for k in range(-1,2,1):
                            temp.append(data[i+z][j+k][0])
            #print(temp)
            temp.sort()
            final_image[i][j][:] = temp[len(temp)//2]
    
    return final_image

vid = mpy.VideoFileClip('shapes_video.mp4')

frame_count = vid.reader.nframes
video_fps = vid.fps
print(video_fps)
frames_list = []

print("Number of frames:",frame_count)


for i in range(frame_count):
    frame = vid.get_frame(i*1.0/video_fps)
    filtered_frame = median_filter(frame)
    frames_list.append(filtered_frame)


clip = moviepy.ImageSequenceClip(frames_list,fps = video_fps)
#clip = moviepy.ImageSequenceClip(images_list, fps = 60)
clip.write_videofile('part1_1_video.mp4', codec = 'libx264')


