import moviepy.video.io.ImageSequenceClip as ImageSequenceClip
import pickle
import matplotlib.pyplot as plt
import torch
import cv2
import numpy as np

with open("stylegan3-t-ffhq-1024x1024.pkl","rb") as f:
    a = pickle.load(f)
#Unpack the GAN network downloaded from the official NVIDIA website.

gan = a["G_ema"].cuda()
#StyleGAN contains both the Generator and the Discriminator. We only need the Generator to generate the images.

gan.eval()
#In PyTorch every network has to be set as 'train' or 'eval'. To evaluate an input via  the network, we should set it as eval.


for param in gan.parameters():
    param.requires_grad = False


z1 = np.load('z1.npy')
z2 = np.load('z2.npy')

z1 = torch.from_numpy(z1).float().cuda()
z2 = torch.from_numpy(z2).float().cuda()
diff = z2-z1

diff = diff/100

l = []


img1 = gan(z1, 0).cpu().numpy().squeeze()
img1 = np.transpose(img1, (1,2,0))

img1[img1>1] = 1
img1[img1<-1] = -1
img1 = (255*(img1+1)/2).astype(np.uint8)


l.append(img1)
for i in range(100):
  z1=z1+diff
  img1 = gan(z1, 0).cpu().numpy().squeeze()
  img1 = np.transpose(img1, (1,2,0))

  img1[img1>1] = 1
  img1[img1<-1] = -1
  img1 = (255*(img1+1)/2).astype(np.uint8)

  l.append(img1)



clip = ImageSequenceClip.ImageSequenceClip(l, 60)
clip.write_videofile("part22.mp4")