import numpy as np
import cv2
import os
import moviepy.editor as moviepy
from numpy.core.fromnumeric import argmax, nonzero


planes = np.zeros((9,472,4,3))

for i in range(1,10):
	with open("Plane_"+str(i)+".txt") as f:
		content = f.readlines()

		for line_id in range(len(content)):
			sel_line = content[line_id]
			sel_line = sel_line.replace(')\n', '').replace("(", '').split(")")

			for point_id in range(4):
				sel_point = sel_line[point_id].split(" ")

				planes[i-1,line_id,point_id,0] = float(sel_point[0])
				planes[i-1,line_id,point_id,1] = float(sel_point[1])
				planes[i-1,line_id,point_id,2] = float(sel_point[2])

images_list = []

background = cv2.imread('myslovitz.jpg')
#background = cv2.imread('uze.jpg')
background = background[:,:,[2,1,0]]
modify_image = background
image_height = modify_image.shape[0]
image_width = modify_image.shape[1]
'''by using code below, I add additional channel to my image. Because I used build-in warpPerspective function,
after transforming image I was not able to split black image from black background. So before transforming, I add new channel to 
3 channel image. That additional channel will store 1 for all cells of image matrix. After transforming black background will
contaion 0 for additional channel, but image contain 1. So by searching the cells that contain have 1 as 4th channel value,
I can split image from background. But I cold not add only 1 channel, below code adding channel taken from stack overflow, which
adds 3 additional channels. I use only one of them, remaining always remain as 0'''
_,alpha = cv2.threshold(modify_image,0,255,cv2.THRESH_BINARY)
b, g, r = cv2.split(modify_image)
rgba = [b,g,r, alpha]
modify_image = cv2.merge(rgba,4)#adding additional channels
modify_image[:,:,3] = 1#making 4th channel 1 for image
#print(modify_image)
cat_image = cv2.imread('cat-headphones.png',cv2.IMREAD_UNCHANGED)
cat_image[:,:,[0,1,2]] =cat_image[:,:,[2,1,0]] 
cat_image = cv2.resize(cat_image, (572,322))
#print(cat_image)
#print(image_height,image_height)
for i in range(472):
	blank_image = np.zeros((322,572,6), np.uint8)
	onde = []#stores the planes which is located front of cat
	arkada =[]#stores the planes which is located behind of cat
	for j in range(9):

			pts = planes[j,i,:,:].squeeze()[:,0:2].astype(np.int32)
			uzaklik = planes[j,i,:,:].squeeze()[:,2:3].astype(np.int32)[0]
			uzaklik2 =planes[j,i,:,:].squeeze()[:,2:3].astype(np.int32)[3]
			temp = np.copy(pts[3,:])
			pts[3, :] = pts[2,:]
			pts[2, :] = temp
			for pt in pts:
				temp = pt[0]
				pt[0]=pt[1]
				pt[1]=temp
			
			src = np.float32([[0,0],[image_width-1,0],[image_width-1,image_height-1],[0,image_height-1]])
			M = np.zeros((8,8))
			b = np.zeros((8,1))
			'''Below part calculates the coefficients of perspective transfotmation'''
			for m in range(4):
					M[m][0] = M[m+4][3] = src[m][0]
					M[m][1] = M[m+4][4] = src[m][1]
					M[m][2] = M[m+4][5] = 1
					M[m][3] = M[m][4] = M[m][5] = 0
					M[m+4][0] = M[m+4][1] = M[m+4][2] = 0
					M[m][6] = -src[m][0]*pts[m][1]
					M[m][7] = -src[m][1]*pts[m][1]
					M[m+4][6] = -src[m][0]*pts[m][0]
					M[m+4][7] = -src[m][1]*pts[m][0]
					b[m] = pts[m][1]
					b[m+4] = pts[m][0]

			coefficients = np.linalg.pinv(M)@b
			#print(pt1.shape)
			#print(pt1)
			#print(pts.shape)
			#print(pts)
			#M = cv2.getPerspectiveTransform(src,pts)
			
			#print(M.shape)
			#print("coef")
			#print(coefficients)
			transformMatrix = np.zeros((3,3))
			count=0
			for k in range(3):
				if count<6:
					transformMatrix[k][count%3]=coefficients[count]
					transformMatrix[k][count%3+1]=coefficients[count+1]
					transformMatrix[k][count%3+2]=coefficients[count+2]
				else:
					transformMatrix[k][count%3]=coefficients[count]
					transformMatrix[k][count%3+1]=coefficients[count+1]
					transformMatrix[2][2]=1
				count = count+3

			dst = cv2.warpPerspective(modify_image,transformMatrix,(572,322))
			'''choose if plane is behind or front of the cat. 160 is obtained by trying the numbers'''
			if(uzaklik>160 and uzaklik2>160):
				arkada.append(dst)
			else:
				onde.append(dst)

	image=blank_image
	image[:,:,:]=255#adding white background
	'''To get the result, I add everything by order. 1st one is white back ground, 2nd one is the planes behind the cat,
	3rd one is cat, 4th one is planes front of the cat'''
	for h in range(len(arkada)):#adding planes behind of the cat
		first  = np.logical_and(arkada[h][:,:,3]>0,1)
		nonzerox,nonzeroy = nonzero(first)
		nonzero_image = arkada[h][nonzerox,nonzeroy,:]
		image[nonzerox,nonzeroy,:] = nonzero_image	
	
	first  = np.logical_and(cat_image[:,:,3]>30,1)#adding cat
	nonX,nonY = nonzero(first)
	#print(image[nonX,nonY].shape, cat_image[nonX,nonY,[0,1,2]].shape)
	image[nonX,nonY,:3] = cat_image[nonX,nonY,:3]


	for h in range(len(onde)):#adding the planes front of the cat
		first  = np.logical_and(onde[h][:,:,3]>0,1)
		nonzerox,nonzeroy = nonzero(first)
		nonzero_image = onde[h][nonzerox,nonzeroy,:]
		image[nonzerox,nonzeroy,:] = nonzero_image		

	images_list.append(image)


#print(images_list[0].shape)

clip = moviepy.ImageSequenceClip(images_list, fps = 60)
clip.write_videofile("part3_video.mp4", codec="libx264")

