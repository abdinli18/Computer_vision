import numpy as np
import cv2
import os
import imutils
import moviepy.editor as moviepy
from numpy.core.fromnumeric import argmax, nonzero

image = cv2.imread('myslovitz.jpg')
#print(image.shape)
#cv2.imshow('Background Image Window',image)
# grab the dimensions of the image and calculate the center of the
# image
(h, w) = image.shape[:2]
(cX, cY) = (w // 2, h // 2)

image_height = image.shape[0]
image_weight = image.shape[1]

centerX = image_weight//2
centerY = image_height//2

'''filling my own rotation matrix'''
rotationMatrix = np.zeros((2,3))
Rotationangle = 60
rotationMatrix[0][0] = np.cos(Rotationangle*np.pi/180)
rotationMatrix[0][1] = -np.sin(Rotationangle*np.pi/180)
rotationMatrix[0][2] = (1-np.cos(Rotationangle*np.pi/180))*cX+ np.sin(Rotationangle*np.pi/180)*cY
rotationMatrix[1][0] = np.sin(Rotationangle*np.pi/180)
rotationMatrix[1][1] = np.cos(Rotationangle*np.pi/180)
rotationMatrix[1][2] = -np.sin(Rotationangle*np.pi/180)*cX + (1-np.cos(Rotationangle*np.pi/180))*cY


'''built in rotation matrix and affine transformation function'''
#M_second = cv2.getRotationMatrix2D((cX, cY), -60, 1.0)
#rotated = cv2.warpAffine(image, M_second, (image_weight, image_height))
#cv2.imshow("Rotated by 60 Degrees due to top-left corner", rotated)

'''affine tranform using my own rotation matrix'''
new_rotated = cv2.warpAffine(image, rotationMatrix, (image_weight, image_height))
#cv2.imshow("Rotated by 60 Degrees due to top-left corner", new_rotated)#it is for displaying rotated image
#cv2.waitKey(0)
cv2.imwrite("part4-center.jpg", new_rotated)#it is