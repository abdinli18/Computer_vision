import numpy as np
import cv2
import os
import imutils
import moviepy.editor as moviepy
from numpy.core.fromnumeric import argmax, nonzero

image = cv2.imread('myslovitz.jpg')
#print(image.shape)
#cv2.imshow('Background Image Window',image)
# grab the dimensions of the image and calculate the center of the
# image
(h, w) = image.shape[:2]
(cX, cY) = (w // 2, h // 2)

image_height = image.shape[0]
image_weight = image.shape[1]

centerX = image_weight//2
centerY = image_height//2


'''filling rotation matrix'''
rotationMatrix = np.zeros((2,3))
Rotationangle = 60
rotationMatrix[0][0] = np.cos(Rotationangle*np.pi/180)
rotationMatrix[0][1] = -np.sin(Rotationangle*np.pi/180)
rotationMatrix[0][2] = rotationMatrix[1][2] = 0
rotationMatrix[1][0] = np.sin(Rotationangle*np.pi/180)
rotationMatrix[1][1] = np.cos(Rotationangle*np.pi/180)


#cv2.imshow("Rotated by 60 Degrees", new_rotated)
#cv2.waitKey(0)

'''built in rotation matrix and affine transformation'''
#M_second = cv2.getRotationMatrix2D((0, 0), -60, 1.0)
#rotated = cv2.warpAffine(image, M_second, (image_weight, image_height))
#cv2.imshow("Rotated by 60 Degrees due to top-left corner", rotated)

'''affine transformation with my own rotation matrix'''
new_rotated = cv2.warpAffine(image, rotationMatrix, (image_weight, image_height))
#cv2.imshow("Rotated by 60 Degrees due to top-left corner", new_rotated)#this line is to display rotated image
#cv2.waitKey(0)
cv2.imwrite("part4-topLeft.jpg", new_rotated)#save image


'''In center ve topleft rotation difference is rotation matrix.
Normally, there rotation matrix is like above for both. it is because there is not something like rotation due to center.
So to obtain rotation due to center, we firstly rotate image due to top left corner, then move the center of image
to the center of the plane. So in this way, we obtain rotation due to center. The rotation matrix in due to center code(in part4-center.py)
is the result of multiplications of 2 matrix. firt one is rotation 60 degrees due to top letf corner multiplied by
the matrix shifting the center of shifted image to the center of the plane'''