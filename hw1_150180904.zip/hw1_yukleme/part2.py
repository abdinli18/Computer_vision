from moviepy.audio.AudioClip import AudioClip
import numpy as np
import os
import cv2
import moviepy.editor as mpy
from numpy.core.fromnumeric import nonzero



#copied from part1.py
background = cv2.imread('Malibu.jpg')
#cv2.imshow('Background Image Window',background)
background_height = background.shape[0]
background_weight = background.shape[1]
ratio = 360/background_height

background = cv2.resize(background, (int(background_weight*ratio),360))
#cv2.imshow('Background Image Window',background)
#print(background.shape)


#main_dir="D:\D_M\Downloads\Computer_vision\Homeworks\HW1\cat"
main_dir = "cat"
images_list = []
numofImages = 180

cat_hist = np.zeros((3,256))
cat_cummulative = np.zeros((3,256))

for i in range(numofImages):
    image  = cv2.imread(main_dir+'\cat_'+str(i)+'.png')
    image_reverse = cv2.flip(image,1)
    foreground  = np.logical_or(image[:,:,1]<180,image[:,:,0]>150)#The pixels having cat image
    foreground_reverse = np.logical_or(image_reverse[:,:,1]<180,image_reverse[:,:,0]>150)
    nonzero_x, nonzero_y = nonzero(foreground)
    nonzero_x_rev, nonzero_y_rev = nonzero(foreground_reverse)
    nonzero_cat_values = image[nonzero_x,nonzero_y,:]#+image_reverse[nonzero_x,image_reverse.shape[1]-1-nonzero_y,:]
    nonzero_cat_values_rev = image_reverse[nonzero_x_rev,nonzero_y_rev,:]

    for k in range(256):
        for channel in range(3):
            cat_hist[channel][k]=cat_hist[channel][k]+np.count_nonzero(nonzero_cat_values_rev[:,channel]==k)#constracting histogram that shows number of colors


for channel in range(3):
    cat_hist[channel] = cat_hist[channel]/numofImages#finding average

#print("ortalama bulundu")

cummulative_count=[0]*3
for k in range(256):#finding cumulative histogram
    for channel in range(3):
        cummulative_count[channel]=cummulative_count[channel]+cat_hist[channel][k]
        cat_cummulative[channel][k]= cummulative_count[channel]

    
for channel in range(3):#find cat cumulative
    cat_cummulative[channel] = cat_cummulative[channel]/(cat_cummulative[channel][-1])
    #print(cat_cummulative[0])
#print("cat cumm hesaplandi")

target_hist = np.zeros((3,256))
target_image  = cv2.imread('target_image.jpeg')
#cv2.imshow('Background Image Window',target_image)
#cv2.waitKey(0)


#doing same calculations for target image
for k in range(256):
    for channel in range(3):
        target_hist[channel][k]+=np.count_nonzero(target_image[:,:,channel]==k)


target_cummulative = np.zeros((3,256))
cummulative_count=[0]*3
for k in range(256):
    for channel in range(3):
        cummulative_count[channel]=cummulative_count[channel]+target_hist[channel][k]
        target_cummulative[channel][k]= cummulative_count[channel]
#print(cat_hist)

#normalize

for channel in range(3):
    target_cummulative[channel] = target_cummulative[channel]/(target_cummulative[channel][-1])

LUT = np.zeros((3,256))

#constracting Look up table
for channel in range(3):
    g_j = 0
    for g_i in range(256):
        while  g_j<256 and target_cummulative[channel][g_j] < cat_cummulative[channel][g_i]:
            g_j = g_j + 1
        LUT[channel][g_i]=g_j


for i in range(numofImages):
    image  = cv2.imread(main_dir+'\cat_'+str(i)+'.png')
    image_reverse = cv2.flip(image,1)

    foreground  = np.logical_or(image[:,:,1]<180,image[:,:,0]>150)#The pixels having cat image
    foreground_reverse = np.logical_or(image_reverse[:,:,1]<180,image_reverse[:,:,0]>150)
    nonzero_x, nonzero_y = nonzero(foreground)
    nonzero_x_rev, nonzero_y_rev = nonzero(foreground_reverse)
    nonzero_cat_values = image[nonzero_x,nonzero_y,:]#+image_reverse[nonzero_x,image_reverse.shape[1]-1-nonzero_y,:]
    nonzero_cat_values_rev = image_reverse[nonzero_x_rev,nonzero_y_rev,:]
    
    for channel in range(3):
        for k in range(256):
            nonzero_cat_values_rev[:,channel][nonzero_cat_values_rev[:,channel]==k] = LUT[channel][k]
    

    new_frame = background.copy()
    new_frame[nonzero_x,nonzero_y,:] = nonzero_cat_values
    width_diffrence = (background.shape[1]-image.shape[1])
    new_frame[nonzero_x_rev,nonzero_y_rev + width_diffrence,:] = nonzero_cat_values_rev
    new_frame = new_frame[:,:,[2,1,0]]
    images_list.append(new_frame)

#cv2.imshow('Background Image Window',image)
clip = mpy.ImageSequenceClip(images_list,fps=25)
audio = mpy.AudioFileClip('selfcontrol_part.wav').set_duration(clip.duration)
clip = clip.set_audio(audioclip = audio)
clip.write_videofile('part2_video.mp4', codec = 'libx264')
cv2.waitKey(0)