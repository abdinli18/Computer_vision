from moviepy.audio.AudioClip import AudioClip
import numpy as np
import os
import cv2
import moviepy.editor as mpy
from numpy.core.fromnumeric import nonzero

'''reading image and its shape'''
background = cv2.imread('Malibu.jpg')
#cv2.imshow('Background Image Window',background)
background_height = background.shape[0]
background_weight = background.shape[1]
ratio = 360/background_height

'''resizing image'''
background = cv2.resize(background, (int(background_weight*ratio),360))
#cv2.imshow('Background Image Window',background)
#print(background.shape)


#main_dir="D:\D_M\Downloads\Computer_vision\Homeworks\HW1\cat"
main_dir = "cat"
images_list = []
numofImages = 180
for i in range(numofImages):
    image  = cv2.imread(main_dir+'\cat_'+str(i)+'.png')#reading images
    image_reverse = cv2.flip(image,1)#flipping it
    foreground  = np.logical_or(image[:,:,1]<180,image[:,:,0]>150)#The pixels having cat image
    foreground_reverse = np.logical_or(image_reverse[:,:,1]<180,image_reverse[:,:,0]>150)#pixels having cat image
    nonzero_x, nonzero_y = nonzero(foreground)
    nonzero_x_rev, nonzero_y_rev = nonzero(foreground_reverse)
    nonzero_cat_values = image[nonzero_x,nonzero_y,:]
    nonzero_cat_values_rev = image_reverse[nonzero_x_rev,nonzero_y_rev,:]
    #print(nonzero_cat_values)
    #print(nonzero_cat_values_rev)
    new_frame = background.copy()
    new_frame[nonzero_x,nonzero_y,:] = nonzero_cat_values#adding cat to background
    width_diffrence = (background.shape[1]-image.shape[1])
    new_frame[nonzero_x_rev,nonzero_y_rev + width_diffrence,:] = nonzero_cat_values_rev#adding reversed cat to background
    new_frame = new_frame[:,:,[2,1,0]]#reversing R,G,B values to B,G,R
    images_list.append(new_frame)

#cv2.imshow('Background Image Window',image)
'''making clip'''
clip = mpy.ImageSequenceClip(images_list,fps=25)
audio = mpy.AudioFileClip('selfcontrol_part.wav').set_duration(clip.duration)
clip = clip.set_audio(audioclip = audio)
clip.write_videofile('part1_video.mp4', codec = 'libx264')
cv2.waitKey(0)