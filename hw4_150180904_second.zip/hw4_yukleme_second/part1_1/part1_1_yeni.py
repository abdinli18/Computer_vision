import cv2
import os
from cv2 import imshow
import numpy as np
import moviepy.editor as mpy



def findBackground(images, start_index):
    sum = np.zeros(images[0].shape).astype(np.float32)
    #print(start_index)
    for i in range(update_after):
        #print(start_index-i)
        sum = sum + images[start_index-i].astype(np.float32)/update_after
    sum = sum.astype(np.uint8)
    return sum


mypath = "D:/D_M/Downloads/Computer_vision/Homeworks/HW4/DJI_0101"

images = []
result_images=[]


update_after = 10


for i in os.listdir(mypath):
    img=cv2.imread(mypath+"/"+i)
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    images.append(img_gray)

background = images[0]




kernel = np.ones((3,3),np.float32)/9
background = cv2.filter2D(background,-1,kernel)



for i in range(len(images)):
    img_filtered=cv2.filter2D(images[i],-1,kernel)
    res = cv2.absdiff(img_filtered,background)
    res[res<=20]=0
    res[res>20]=255
    res = cv2.dilate(res, kernel, iterations=1)
    res = cv2.dilate(res, kernel, iterations=1)
    res = cv2.erode(res, kernel, iterations=1)
    res = cv2.erode(res, kernel, iterations=1)
    res = cv2.cvtColor(res, cv2.COLOR_GRAY2BGR)
    result_images.append(res)
    if(i>=9 and i!=len(images)-1):
        background = findBackground(images, i+1)
        background = cv2.filter2D(background,-1,kernel)


def optical_flow(first_img, second_img,index, img_for_video):
    first_gray = cv2.cvtColor(first_img, cv2.COLOR_BGR2GRAY)
    second_gray = cv2.cvtColor(second_img, cv2.COLOR_BGR2GRAY)
    I1 = np.array(first_gray)
    I2 = np.array(second_gray)
    S = np.shape(I1)

    #smooth image
    print(index)
    I1_smooth = cv2.GaussianBlur(I1, (3,3), 0)
    I2_smooth = cv2.GaussianBlur(I2, (3,3), 0)


    Ix = cv2.Sobel(I1_smooth, cv2.CV_32F, 1, 0)
    Iy = cv2.Sobel(I1_smooth, cv2.CV_32F, 0, 1)


    It = (I2_smooth-I1_smooth)
   

    features = cv2.goodFeaturesToTrack(I1_smooth ,100, 0.01,10)

    features2 = cv2.goodFeaturesToTrack(I2_smooth ,100, 0.01,10)
    
    not_good =[445,453]

    #img_for_video= cv2.cvtColor(first_img, cv2.COLOR_GRAY2BGR)
    if(index not in not_good):
        #print("girdi")
        feature = np.int0(features)

        #feature2 = np.int0(features2)

        u = np.zeros(S)
        v = np.zeros(S) 
        for l in feature:
            j,i = l.ravel()
            #print(j, i, "rakam")
            IX = ([Ix[i-1,j-1],Ix[i,j-1],Ix[i+1,j-1],Ix[i-1,j],Ix[i,j],Ix[i+1,j],Ix[i-1,j+1],Ix[i,j+1],Ix[i+1,j+1]]) #The x-component of the gradient vector
            IY = ([Iy[i-1,j-1],Iy[i,j-1],Iy[i+1,j-1],Iy[i-1,j],Iy[i,j],Iy[i+1,j],Iy[i-1,j+1],Iy[i,j+1],Iy[i+1,j+1]]) #The Y-component of the gradient vector
            IT = ([It[i-1,j-1],It[i,j-1],It[i+1,j-1],It[i-1,j],It[i,j],It[i+1,j],It[i-1,j+1],It[i,j+1],It[i+1,j+1]]) #The XY-component of the gradient vector

            #Ixx = IX*IX
            #Iyy = IY*IY
            A = np.array([IX,IY]).T
            #print(A)
            ATA = A.T@A
            ATA_inv = np.linalg.inv(ATA)
            (u[i,j],v[i,j]) = ATA_inv@(A.T@IT)    
        
        #img_for_video= cv2.cvtColor(first_img, cv2.COLOR_GRAY2BGR)
        t=0.2
        vec_img = []
        imm = first_img
        #print(u,"u")
        #print(v,"v")

        girdi=False

        for i in range(S[0]):
                for j in range(S[1]):
                    if abs(u[i,j])>=t or abs(v[i,j])>=t: # setting the threshold to plot the vectors
                        #plt.arrow()
                        #print(i,j)
                        girdi=True
                        '''print(u[i,j])
                        print(v[i,j])
                        print(round(u[i,j]))
                        print(round(v[i,j]))'''
                        #print("okay")
                        #print(np.int(abs(u[i,j])))
                        #print(round(abs(u[i,j])))
                        #print("buraya")
                        cv2.imshow("a", img_for_video)
                        cv2.waitKey(0)
                        imm = cv2.arrowedLine(img_for_video,(j,i),(j+round(u[i,j]*40),i+round(v[i,j]*40)),(0, 255,0),thickness=1)
                        #imm = cv2.arrowedLine(first_img,(j,i),(j+round(v[i,j]*40),i+round(u[i,j]*40)),(0, 255,0),thickness=1) To see vectors good enough this line can be used
                        #cv2.imshow("immm", imm)
                        #cv2.imshow("immm1", first_img)
                        #cv2.imshow("immm2", second_img)
                        #cv2.waitKey(0)
        if(girdi==True):
            imm = imm[:,:,[2,1,0]]
        else:
            imm = img_for_video[:,:,[2,1,0]]
        return imm
    else:
        print("buraya")
        img_for_video = img_for_video[:,:,[2,1,0]]
        return img_for_video

mypath = "D:/D_M/Downloads/Computer_vision/Homeworks/HW4/DJI_0101"

images = []
#result_images=[]
vectored_images=[]

for i in os.listdir(mypath):
    img=cv2.imread(mypath+"/"+i)
    images.append(img)

print(len(result_images))
for i in range(1,len(result_images)-5,4):
    first = result_images[i]
    second = result_images[i+4]
    vectored_image = optical_flow(first, second,i, images[i])
    vectored_images.append(vectored_image)
    #print(i)



print(len(vectored_images))
clip = mpy.ImageSequenceClip(vectored_images,fps=5)
clip.write_videofile('part1_1video_yeni.mp4', codec = 'libx264')