from copy import copy
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
import numpy as np
import pandas as pd
import os
from sklearn.decomposition import PCA

train_x = np.load('train_saved_eski.npy')
train_y = np.int32(np.load('train_labels_saved_eski.npy'))
print("train_files read")

#print(train_y)
print(len(train_y))
print(train_x.shape)


print("pca basladi")
pca = PCA(n_components=2048, copy=False)
train_x = pca.fit_transform(train_x)
print("pca bitti")

test_x = np.load('test_saved_eski.npy')
test_labels = np.load('test_labels_saved_eski.npy')
print("test_files read")

print("pca test basladi")
test_x = pca.transform(test_x)
print("pca test bitti")


knn = KNeighborsClassifier(n_neighbors=60, weights="distance")
knn.fit(train_x, train_y)
print("train finished")
y_pred = knn.predict(test_x)
print("prediction finished")

#dir = "D:/D_M/Downloads/Computer_vision/Homeworks/HW1/bonus_question/imagenet_50/train"
dir = "D:/D_M/Downloads/Computer_vision/Homeworks/HW4/Kaggle/imagenet_50/train"
test_files = sorted(os.listdir(dir))

result = []
for i, name in enumerate(test_labels):
    print(i,"i kac")
    #print(int(y_pred[i]), "int y_pred")
    #print(y_pred[i], "y_pred")
    result.append([name, test_files[int(y_pred[i])]])
pd.DataFrame(np.array(result)).to_csv("predictions.csv", header=["FileName","Class"], index=False)

