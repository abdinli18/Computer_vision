import cv2
import os
import numpy as np
import moviepy.editor as mpy



def findBackground(images, start_index):
    sum = np.zeros(images[0].shape).astype(np.float32)
    #print(start_index)
    for i in range(update_after):
        #print(start_index-i)
        sum = sum + images[start_index-i].astype(np.float32)/update_after
    sum = sum.astype(np.uint8)
    return sum


mypath = "D:/D_M/Downloads/Computer_vision/Homeworks/HW4/DJI_0101"

images = []
result_images=[]


update_after = 10


for i in os.listdir(mypath):
    img=cv2.imread(mypath+"/"+i)
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    images.append(img_gray)

background = images[0]




kernel = np.ones((3,3),np.float32)/9
background = cv2.filter2D(background,-1,kernel)


for i in range(len(images)):
    img_filtered=cv2.filter2D(images[i],-1,kernel)
    res = cv2.absdiff(img_filtered,background)
    res[res<=20]=0
    res[res>20]=255
    res = cv2.dilate(res, kernel, iterations=1)
    res = cv2.dilate(res, kernel, iterations=1)
    res = cv2.erode(res, kernel, iterations=1)
    res = cv2.erode(res, kernel, iterations=1)
    res = cv2.cvtColor(res, cv2.COLOR_GRAY2BGR)
    result_images.append(res)
    if(i>=9 and i!=len(images)-1):
        background = findBackground(images, i+1)
        background = cv2.filter2D(background,-1,kernel)




clip = mpy.ImageSequenceClip(result_images,fps=25)
clip.write_videofile('part1_2video.mp4', codec = 'libx264')