from re import I
from cv2 import imshow, waitKey
import moviepy.editor as mpy
import cv2
import os
import numpy as np
from copy import deepcopy
from scipy import signal



def optical_flow(first_img, second_img):
    first_gray = cv2.cvtColor(first_img, cv2.COLOR_BGR2GRAY)
    second_gray = cv2.cvtColor(second_img, cv2.COLOR_BGR2GRAY)
    I1 = np.array(first_gray)
    I2 = np.array(second_gray)
    S = np.shape(I1)

    #smooth image
    I1_smooth = cv2.GaussianBlur(I1, (3,3), 0)
    I2_smooth = cv2.GaussianBlur(I2, (3,3), 0)


    Ix = cv2.Sobel(I1_smooth, cv2.CV_32F, 1, 0)
    Iy = cv2.Sobel(I1_smooth, cv2.CV_32F, 0, 1)


    It = (I2_smooth-I1_smooth)
   

    features = cv2.goodFeaturesToTrack(I1_smooth ,100, 0.01,10)

    features2 = cv2.goodFeaturesToTrack(I2_smooth ,100, 0.01,10)
    feature = np.int0(features)
    feature2 = np.int0(features2)

    u = v = np.nan*np.ones(S)
    for l in feature:
        j,i = l.ravel()

        IX = ([Ix[i-1,j-1],Ix[i,j-1],Ix[i+1,j-1],Ix[i-1,j],Ix[i,j],Ix[i+1,j],Ix[i-1,j+1],Ix[i,j+1],Ix[i+1,j+1]]) #The x-component of the gradient vector
        IY = ([Iy[i-1,j-1],Iy[i,j-1],Iy[i+1,j-1],Iy[i-1,j],Iy[i,j],Iy[i+1,j],Iy[i-1,j+1],Iy[i,j+1],Iy[i+1,j+1]]) #The Y-component of the gradient vector
        IT = ([It[i-1,j-1],It[i,j-1],It[i+1,j-1],It[i-1,j],It[i,j],It[i+1,j],It[i-1,j+1],It[i,j+1],It[i+1,j+1]]) #The XY-component of the gradient vector


        A = np.array([IX,IY]).T
        #print(A)
        ATA = A.T@A
        ATA_inv = np.linalg.inv(ATA)
        (u[i,j],v[i,j]) = ATA_inv@(A.T@IT)    

    t=0
    vec_img = []
    imm = first_img
    for i in range(S[0]):
            for j in range(S[1]):
                if abs(u[i,j])>=t or abs(v[i,j])>=t: # setting the threshold to plot the vectors
                    #plt.arrow()
                    #print(i,j)
                    '''print(u[i,j])
                    print(v[i,j])
                    print(round(u[i,j]))
                    print(round(v[i,j]))'''
                    #print("okay")
                    #print(np.int(abs(u[i,j])))
                    #print(round(abs(u[i,j])))
                    imm = cv2.arrowedLine(first_img,(j,i),(j+round(v[i,j]*4),i+round(u[i,j]*4)),(0, 255,0),thickness=1)
                    #imm = cv2.arrowedLine(first_img,(j,i),(j+round(v[i,j]*40),i+round(u[i,j]*40)),(0, 255,0),thickness=1) To see vectors good enough this line can be used
                    #cv2.imshow("immm", imm)
                    #cv2.imshow("immm1", first_img)
                    #cv2.imshow("immm2", second_img)
                    #cv2.waitKey(0)
    imm = imm[:,:,[2,1,0]]
    return imm

mypath = "D:/D_M/Downloads/Computer_vision/Homeworks/HW4/DJI_0101"

images = []
result_images=[]
vectored_images=[]

for i in os.listdir(mypath):
    img=cv2.imread(mypath+"/"+i)
    images.append(img)

for i in range(0,len(images)-5,4):
    first = images[i]
    second = images[i+4]
    vectored_image = optical_flow(first, second)
    vectored_images.append(vectored_image)

clip = mpy.ImageSequenceClip(vectored_images,fps=5)
clip.write_videofile('part1_1video_yukleme.mp4', codec = 'libx264')